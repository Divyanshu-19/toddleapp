import logo from './logo.svg';
import './App.css';
import Otp from "./features/otp/Otp"

function App() {
  return (
    <div style={{display: "flex", justifyItems: "center", alignItems:"center", height: "100vh"}}>
      <Otp 
        noOfInputs = {6}
      />
    </div>
  );
}

export default App;
