import React, { useState, useRef } from "react";

const InputFields = ({id, shiftRight, shiftLeft, focus, initialValue}) => {
  const [otp, setOtp] = useState(initialValue);
  const otpRef = useRef();

  const handleKey = (e) => {
    if(e.code==="Backspace" && otp.length===0){
        shiftLeft(id);
    }
    if(e.code==="Backspace" && otp.length===1){
        setOtp("")
        shiftLeft(id);
    }
  }


  const handleOtpValue = (e) => {
    if(e.target.value.length<=1 && e.target.value!==""){
        setOtp(e.target.value)
        shiftRight(id);
    }
    if(e.target.value.length>1){
        setOtp(e.target.value.slice(0,1));
        shiftRight(id, e.target.value.slice(1));
    }
  }


  return (
    <>
    {focus ? otpRef.current.focus(): null}
    <input
        id="otptext"
      type="text"
      value={otp}
      ref={otpRef}
      onChange={(e) => handleOtpValue(e)}
      onKeyDownCapture={(e) => handleKey(e)}
    />
    </>
  );
};

export default InputFields;
