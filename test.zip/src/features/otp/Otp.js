import React, { useEffect, useState } from "react";
import InputFields from "./component/InputField";

const Otp = ({ noOfInputs }) => {
  const [otp, setOtp] = useState(new Array(noOfInputs).fill());
  const [focus, setFocus] = useState(new Array(noOfInputs).fill(false));
  const [passvalue, setPassvalue] = useState({id: null, value: ''});

  useEffect(() => {
    console.log(focus)
  }, [focus])


  const shiftRight = (id, value) => {
    if(id===noOfInputs-1){
        return;
    }
    setPassvalue({id, value});

    setFocus(prev => {
        let newarr = new Array(noOfInputs).fill(false);
        newarr[id+1] = true;
        return newarr;
    });
  }

  const shiftLeft = (id) => {
    if(id===0){
        return;
    }
    setFocus(prev => {
        let newarr = new Array(noOfInputs).fill(false);
        newarr[id-1] = true;
        return newarr;
    });
  }

  return (
    <div style={{ height: "20vh", border: "1px solid black" }}>
      <h2>Enter received code</h2>
      {otp.map((element, index) => {
        return (
          <div key={index}>
            <InputFields id={index} shiftRight={shiftRight} shiftLeft={shiftLeft} focus={focus[index]} initialValue={''} />
          </div>
        );
      })}
    </div>
  );
};

export default Otp;
