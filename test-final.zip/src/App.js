import logo from './logo.svg';
import './App.css';
import Otp from "./features/otp/Otp"

function App() {
  return (
    <div style={{display: "flex", justifyContent: "center", alignItems:"center", height: "100vh", backgroundColor: "#FAF9F6"}}>
      <Otp 
        noOfInputs = {5}
        seperator = {"0"}
        value={"1"}
        placeholder={"12345678"}
        // isDisabled={true}
        hasErrored={true}
        isInputSecured={false}
        isInputNum={true}
      />
    </div>
  );
}

export default App;
