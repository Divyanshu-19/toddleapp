import React, { useState, useRef, useEffect } from "react";

const InputFields = ({
  id,
  shiftRight,
  shiftLeft,
  focus,
  initialValue,
  copyVal,
  setCopyVal,
  clear,
  handleOtpChange,
  placeholder,
  isDisabled,
  hasErrored,
  isInputSecured,
  isInputNum
}) => {
  const [otp, setOtp] = useState(initialValue);
  const otpRef = useRef();

  const inputFieldStyle = {
    height: "5rem",
    width: "5rem",
    fontSize: "2rem",
    textAlign: "center",
    borderRadius: "10px",
    margin: "1rem",
    borderColor: hasErrored ? "red" : "lightgray",
    boxShadow: "none",
  };

  useEffect(() => {
    if (copyVal && copyVal.id === id) {
      if (copyVal.value.length > 1) {
        setOtp(copyVal.value.slice(0, 1));
        handleOtpChange(id, copyVal.value.slice(0, 1));
        shiftRight(id, copyVal.value.slice(1));
      } else if (copyVal.value.length === 1) {
        setOtp(copyVal.value);
        handleOtpChange(id, copyVal.value);
        setCopyVal({});
      }
    }
  }, [copyVal]);

  useEffect(() => {
    setOtp("");
    handleOtpChange(id, "");
    shiftLeft(1)
  }, [clear])

  const handleKey = (e) => {
    if (e.code === "Backspace" && otp.length === 0) {
      shiftLeft(id);
    }
    if (e.code === "Backspace" && otp.length === 1) {
      setOtp("");
      handleOtpChange(id, "");
      shiftLeft(id);
    }
  };

  const handleOtpValue = (e) => {
    if(!(!isNaN(parseFloat(e.target.value)) && !isNaN(e.target.value))){
        return;
    }
    if (e.target.value.length <= 1 && e.target.value !== "") {
      setOtp(e.target.value);
      handleOtpChange(id, e.target.value);
      shiftRight(id);
    }
    if (e.target.value.length > 1) {
      setOtp(e.target.value.slice(0, 1));
      handleOtpChange(id, e.target.value.slice(0, 1));
      shiftRight(id, e.target.value.slice(1));
    }
  };

  return (
    <>
      {focus ? otpRef.current.focus() : null}
      <input
        style={inputFieldStyle}
        id="otptext"
        type={isInputSecured ? "password" : "text"}
        placeholder={placeholder ? placeholder : ""}
        value={otp}
        ref={otpRef}
        onChange={(e) => handleOtpValue(e)}
        onKeyDownCapture={(e) => handleKey(e)}
        disabled={isDisabled}
      />
    </>
  );
};

export default InputFields;
