import React, { useEffect, useState } from "react";
import InputFields from "./component/InputField";

const Otp = ({
  noOfInputs,
  seperator,
  value,
  placeholder,
  isDisabled,
  hasErrored,
  isInputSecured,
  isInputNum
}) => {
  const buttonStyle = {
    fontSize: "1rem",
    color: "white",
    backgroundColor: "#0275d8",
    boxShadow: "none",
    padding: "0.4rem 1rem",
    margin: "3rem 1rem",
  };
  const [otp, setOtp] = useState(new Array(noOfInputs).fill());
  const [focus, setFocus] = useState(new Array(noOfInputs).fill(false));
  const [copyVal, setCopyVal] = useState({});
  const [clear, setClear] = useState(0);

  const placeholderArr = placeholder ? placeholder.split("") : [];

  useEffect(() => {
    setCopyVal({ id: 0, value: value });
  }, [value]);

  const shiftRight = (id, value) => {
    if (id === noOfInputs - 1) {
      return;
    }
    if (value) {
      setCopyVal({ id: id + 1, value: value });
    }

    setFocus((prev) => {
      let newarr = new Array(noOfInputs).fill(false);
      newarr[id + 1] = true;
      return newarr;
    });
  };

  const shiftLeft = (id) => {
    if (id === 0) {
      return;
    }

    setFocus((prev) => {
      let newarr = new Array(noOfInputs).fill(false);
      newarr[id - 1] = true;
      return newarr;
    });
  };

  const handleOtpChange = (id, value) => {
    setOtp((prev) => {
      const newArr = [...prev];
      newArr[id] = value;
      return newArr;
    });
  };

  const handleVerify = () => {
    alert(otp.join(''))
  }

  const handleClear = () => {
    setClear(prev => prev+1);
  }

  return (
    <div
      style={{
        border: "1px solid black",
        fontSize: "large",
        textAlign: "center",
        backgroundColor: "white",
        padding: "1rem 4rem",
      }}
    >
      <h2>Enter received code</h2>
      <div style={{ display: "flex" }}>
        {otp.map((element, index) => {
          return (
            <div key={index}>
              <InputFields
                id={index}
                shiftRight={shiftRight}
                shiftLeft={shiftLeft}
                focus={focus[index]}
                initialValue={""}
                copyVal={copyVal}
                setCopyVal={setCopyVal}
                clear={clear}
                handleOtpChange={handleOtpChange}
                placeholder={
                  placeholderArr.length > index ? placeholderArr[index] : null
                }
                isDisabled={isDisabled}
                hasErrored={hasErrored}
                isInputSecured={isInputSecured}
                isInputNum={isInputNum}
              />
              {seperator && index !== noOfInputs - 1 ? seperator : null}
            </div>
          );
        })}
      </div>
      <button style={buttonStyle} onClick={handleClear}>Clear</button>
      <button style={buttonStyle} onClick={handleVerify}>Verify</button>
    </div>
  );
};

export default Otp;
